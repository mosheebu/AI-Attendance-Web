# SmartAttend AI — HTML + CSS + Python Flask

A local web interface for face-recognition attendance. The UI is HTML templates styled with CSS; Flask and OpenCV handle registration, face model training, attendance records, and optional parent email notifications.

## Requirements
- Windows 10/11
- Python 3.10 or newer (64-bit recommended)
- Webcam
- Internet connection for package installation; SMTP access for email notifications

## Run on Windows
1. Extract the ZIP.
2. Open the extracted folder in File Explorer, click the address bar, type `powershell`, and press Enter.
3. Install packages:
   ```powershell
   py -m pip install -r requirements.txt
   ```
4. Optional: configure Gmail parent notifications in the same PowerShell window. Use a Google App Password, not your normal account password:
   ```powershell
   $env:SMTP_EMAIL="your-sender@gmail.com"
   $env:SMTP_APP_PASSWORD="your-16-character-app-password"
   ```
5. Start the website:
   ```powershell
   py app.py
   ```
6. Open `http://127.0.0.1:5000` in your browser.
7. Register students and capture face samples. The registration camera preview opens in a separate OpenCV window; look toward the camera and press Q to stop early.
8. Click **Train face AI model** on the dashboard, then **Start live attendance**.

## Email behavior
When a student is recognized and attendance is newly saved for that date, the app sends a notification to the saved parent/guardian email if `SMTP_EMAIL` and `SMTP_APP_PASSWORD` are configured. For Gmail, enable 2-Step Verification and create an App Password. Email errors are printed in the PowerShell window. If attendance was already marked that day, no duplicate email is sent.

Optional SMTP settings: `SMTP_HOST` (default `smtp.gmail.com`) and `SMTP_PORT` (default `587`).

## Files
- `app.py`: Python Flask backend and OpenCV logic
- `templates/`: HTML pages
- `static/style.css`: scenic night-sky/mountain design and responsive layout
- `haarcascade_frontalface_default.xml`: face detector
- `data/faces/`: captured face samples; created automatically
- `data/trainer.yml`: trained model; created after training
- `attendance.db`: SQLite database; created automatically

## Privacy and limitations
Face images, attendance history, parent emails, and optional medical notes are sensitive. Use only with school/guardian permission and restrict access to the project folder. The website binds to `127.0.0.1` by default and is intended for use on the same computer, not public deployment. Face recognition can make mistakes; verify attendance records. The 30-day analytics percentage is a rough reference, not an official school-calendar metric.
